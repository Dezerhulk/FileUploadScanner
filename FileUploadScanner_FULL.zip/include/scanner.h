#pragma once
#include <string>

class Scanner {
public:
    void analyzeServerResponse(const std::string& response);
};
