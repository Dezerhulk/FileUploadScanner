#include "scanner.h"
#include <iostream>

void Scanner::analyzeServerResponse(const std::string& response) {
    std::cout << "[Scanner] Response: " << response << std::endl;
}
